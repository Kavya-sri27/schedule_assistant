"""
Generates 30 days of realistic sample schedule data starting from today.
Run: python data/generate_schedule.py
Produces: data/schedule.json  (this is the single source of truth / "system of record")
"""
import json
import random
import uuid
from datetime import datetime, timedelta

random.seed(42)

TODAY = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

EVENT_POOL = [
    ("meeting", "1:1 with Manager", 30, "Weekly sync, discuss priorities and blockers"),
    ("meeting", "Product Sync", 60, "Cross-functional roadmap review"),
    ("meeting", "Client Call - Acme Corp", 45, "Quarterly business review"),
    ("meeting", "Engineering Standup", 15, "Daily team standup"),
    ("meeting", "Design Review", 60, "Review new UI mockups with design team"),
    ("meeting", "Budget Planning", 90, "Q3 budget allocation discussion"),
    ("workshop", "Agentic AI Workshop", 180, "Hands-on workshop on building RAG agents"),
    ("workshop", "Leadership Training", 240, "Full-day leadership development session"),
    ("workshop", "Data Privacy Compliance Training", 120, "Mandatory annual compliance workshop"),
    ("task", "Prepare Quarterly Report", 120, "Draft and finalize Q3 report"),
    ("task", "Code Review - PR #482", 45, "Review pull request for auth module"),
    ("task", "Update Project Roadmap", 60, "Revise roadmap based on latest feedback"),
    ("task", "Respond to Client Emails", 30, "Clear inbox backlog"),
    ("task", "Prepare Slides for Board Meeting", 90, "Slide deck for upcoming board review"),
    ("appointment", "Dentist Appointment", 60, "Routine dental checkup"),
    ("appointment", "Annual Health Checkup", 90, "General physician visit"),
    ("appointment", "Car Service", 120, "Scheduled vehicle maintenance"),
    ("appointment", "Haircut", 30, "Personal appointment"),
    ("meeting", "Interview - Backend Engineer Candidate", 60, "Technical interview round 2"),
    ("meeting", "Vendor Negotiation Call", 45, "Contract renewal discussion"),
]

WORK_HOURS = list(range(9, 18))  # 9 AM - 5 PM


def random_time_slot(used_slots):
    """Pick a start hour/minute not overlapping existing slots for that day (best effort)."""
    for _ in range(20):
        hour = random.choice(WORK_HOURS)
        minute = random.choice([0, 15, 30, 45])
        if (hour, minute) not in used_slots:
            used_slots.add((hour, minute))
            return hour, minute
    return random.choice(WORK_HOURS), 0


def generate_schedule(num_days=30, min_per_day=1, max_per_day=3):
    events = []
    for day_offset in range(num_days):
        day = TODAY + timedelta(days=day_offset)
        # Weekends get fewer / lighter events
        is_weekend = day.weekday() >= 5
        n_events = random.randint(0, 1) if is_weekend else random.randint(min_per_day, max_per_day)
        used_slots = set()
        for _ in range(n_events):
            event_type, title, duration, notes = random.choice(EVENT_POOL)
            hour, minute = random_time_slot(used_slots)
            start = day.replace(hour=hour, minute=minute)
            end = start + timedelta(minutes=duration)
            events.append({
                "id": str(uuid.uuid4())[:8],
                "date": start.strftime("%Y-%m-%d"),
                "day_of_week": start.strftime("%A"),
                "start_time": start.strftime("%H:%M"),
                "end_time": end.strftime("%H:%M"),
                "title": title,
                "type": event_type,
                "notes": notes,
            })
    events.sort(key=lambda e: (e["date"], e["start_time"]))
    return events


def event_to_text(e):
    """Text representation used for embedding / retrieval."""
    return (
        f"{e['type'].capitalize()}: {e['title']} on {e['day_of_week']}, {e['date']} "
        f"from {e['start_time']} to {e['end_time']}. Notes: {e['notes']}"
    )


if __name__ == "__main__":
    schedule = generate_schedule()
    with open("data/schedule.json", "w") as f:
        json.dump(schedule, f, indent=2)
    print(f"Generated {len(schedule)} events across 30 days -> data/schedule.json")
